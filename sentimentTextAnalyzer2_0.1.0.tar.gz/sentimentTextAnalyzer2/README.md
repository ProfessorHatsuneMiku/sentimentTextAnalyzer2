
<!-- README.md is generated from README.Rmd. Please edit that file -->

# sentimentTextAnalyzer2

The goal of sentimentTextAnalyzer2 is to provide positive and negative
sentiment insights of user-inputted files and URL links. Then, it can
generate word clouds of its findings.
